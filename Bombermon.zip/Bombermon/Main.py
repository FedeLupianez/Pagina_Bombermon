import pygame
from pygame.locals import *
from Objetos import Player, Bomb, PowerUp
from menu import Menu, Pantalla_Fin



def main():
    
    
    Sprites_Player_1, Sprites_Player_2 = Menu()

    # Constantes :
    ANCHO: int = 740
    ALTO: int = 640 
    Velocidad_Player_1: int = 11
    Velocidad_Player_2: int = 11
    TiempoDePowerUps: int = 10000


    PANTALLA = pygame.display.set_mode((ANCHO, ALTO))
    pygame.display.set_caption("Bombermón")
    pygame.display.set_icon(pygame.image.load(
        "Imgs/BombaYExplosion/Pokeball_0.png"))

    img_corazon = pygame.transform.scale(pygame.image.load("Imgs/Poderes/Vida.png"), [23, 23])
    clock = pygame.time.Clock()
    FPS: int = 60

    # Letra para las vidas de los jugadores:
    letra = pygame.font.Font("Imgs/Minecraft.ttf", 23)
    
    ImgVidas = {
        1: {
            1: letra.render(f"Jugador 1 : 1", False, (255, 255, 255)),
            2: letra.render(f"Jugador 1 : 2", False, (255, 255, 255)),
            3: letra.render(f"Jugador 1 : 3", False, (255, 255, 255)),
            4: letra.render(f"Jugador 1 : 4", False, (255, 255, 255)),
            5: letra.render(f"Jugador 1 : 5", False, (255, 255, 255))
        },
        2: {
            1: letra.render(f"Jugador 2 : 1", False, (255, 255, 255)),
            2: letra.render(f"Jugador 2 : 2", False, (255, 255, 255)),
            3: letra.render(f"Jugador 2 : 3", False, (255, 255, 255)),
            4: letra.render(f"Jugador 2 : 4", False, (255, 255, 255)),
            5: letra.render(f"Jugador 2 : 5", False, (255, 255, 255))
        }
    }

    # Cargar el Mapa :
    Obstaculos_Fondo: list = [
        [pygame.rect.Rect(644, 514, 50, 50), pygame.rect.Rect(644, 394, 50, 50), pygame.rect.Rect(644, 274, 50, 50),
         pygame.rect.Rect(644, 154, 50, 50), pygame.rect.Rect(
            644, 34, 50, 50), pygame.rect.Rect(524, 34, 50, 50),
         pygame.rect.Rect(404, 34, 50, 50), pygame.rect.Rect(
            284, 34, 50, 50), pygame.rect.Rect(164, 34, 50, 50),
         pygame.rect.Rect(44, 34, 50, 50), pygame.rect.Rect(
            44, 154, 50, 50), pygame.rect.Rect(164, 154, 50, 50),
         pygame.rect.Rect(284, 154, 50, 50), pygame.rect.Rect(
            404, 154, 50, 50), pygame.rect.Rect(524, 154, 50, 50),
         pygame.rect.Rect(524, 274, 50, 50), pygame.rect.Rect(
            404, 274, 50, 50), pygame.rect.Rect(284, 274, 50, 50),
         pygame.rect.Rect(164, 274, 50, 50), pygame.rect.Rect(
            44, 274, 50, 50), pygame.rect.Rect(44, 394, 50, 50),
         pygame.rect.Rect(44, 514, 50, 50), pygame.rect.Rect(
            164, 514, 50, 50), pygame.rect.Rect(164, 394, 50, 50),
         pygame.rect.Rect(284, 394, 50, 50), pygame.rect.Rect(
            284, 514, 50, 50), pygame.rect.Rect(404, 514, 50, 50),
         pygame.rect.Rect(404, 394, 50, 50), pygame.rect.Rect(524, 394, 50, 50), pygame.rect.Rect(524, 514, 50, 50)],

        [pygame.rect.Rect(584, 574, 50, 50), pygame.rect.Rect(644, 454, 50, 50), pygame.rect.Rect(464, 334, 50, 50),
         pygame.rect.Rect(344, 154, 50, 50), pygame.rect.Rect(
            224, 274, 50, 50), pygame.rect.Rect(224, 454, 50, 50),
         pygame.rect.Rect(584, 214, 50, 50), pygame.rect.Rect(
            224, 94, 50, 50), pygame.rect.Rect(104, 514, 50, 50),
         pygame.rect.Rect(224, 574, 50, 50), pygame.rect.Rect(
            44, 94, 50, 50), pygame.rect.Rect(104, 34, 50, 50),
         pygame.rect.Rect(464, 574, 50, 50), pygame.rect.Rect(44, 334, 50, 50), pygame.rect.Rect(104, 454, 50, 50)]
    ]

    Puntos: list = [(71, 244), (71, 484), (71, 604), (71, 664), (71, 724), (71, 784), (71, 844), (131, 184), (131, 244), (131, 304), (131, 364), (131, 424), (131, 604), (131, 664), (131, 724), (131, 784), (131, 844), (191, 124), (191, 244), (191, 364),
                    (191, 484), (191, 604), (191, 664), (191, 724), (191, 784), (191, 844), (251, 64), (251, 184), (251, 244), (251, 364), (251, 424), (251, 544), (251, 664), (251, 724), (251, 784), (251, 844), (311, 124), (311, 244), (311, 364), (311, 484), (311, 604), (311, 724), (311, 784), (311, 844), (371,
                                                                                                                                                                                                                                                                                                                    64), (371, 124), (371, 244), (371, 304), (371, 364), (371, 424), (371, 484), (371, 544), (371, 604), (371, 724), (371, 784), (371, 844), (431, 124), (431, 244), (431, 364), (431, 484), (431, 604), (431, 724), (431, 784), (431, 844), (491, 64), (491, 124), (491, 184), (491, 244), (491, 304),
                    (491, 424), (491, 484), (491, 544), (491, 664), (491, 724), (491, 784), (491, 844), (551, 124), (551, 244), (551, 364), (551, 484), (551, 604), (551, 664), (551, 724), (551, 784), (551, 844), (611, 64), (611, 124), (611, 184), (611, 304), (611, 364), (611, 424), (611, 484), (611, 664), (611, 724), (611, 784), (611, 844), (671, 124), (671, 244), (671, 364), (671, 604), (671, 664), (671, 724), (671, 784), (671, 844), (731, 64), (731, 124), (731, 184), (731, 244), (731, 304), (731, 364), (731, 424), (731, 484), (731, 544), (731, 604), (731, 664), (731, 724), (731, 784), (731, 844), (791, 64), (791, 124), (791, 184), (791, 244), (791, 304), (791, 364), (791, 424), (791, 484), (791, 544), (791, 604), (791, 664), (791, 724), (791, 784), (791, 844), (851, 64), (851, 124), (851, 184), (851, 244), (851, 304), (851, 364), (851, 424), (851, 484), (851, 544), (851, 604), (851, 664), (851, 724), (851, 784), (851, 844)]

    def TopesDePantalla(Jugador):
        if Jugador.hitbox.left <= 0:
            Jugador.hitbox.centerx += Jugador.velocidad

        if Jugador.hitbox.right > ANCHO:
            Jugador.hitbox.centerx -= Jugador.velocidad

        if Jugador.hitbox.top < 0:
            Jugador.hitbox.centery += Jugador.velocidad

        if Jugador.hitbox.bottom > ALTO:
            Jugador.hitbox.centery -= Jugador.velocidad
            

    # Cargar Imágenes de Fondo:
    Fondo = pygame.transform.scale(
        pygame.image.load("Imgs/Fondos/Fondo.png"), [ANCHO, ALTO])
    FondoRect = Fondo.get_rect()

    ImagenObstaculo = pygame.transform.scale(
        pygame.image.load("Imgs/Fondos/Caja.png"), [60, 60])
    ImagenCajaQueSeRompe = pygame.transform.scale(
        pygame.image.load("Imgs/Fondos/SeRompe.png"), [60, 60])

    # Función que dibuja de nuevo las cosas del fondo :

    RectTexto_1 = ImgVidas[1][1].get_rect(center=(105, 17))
    RectTexto_2 = ImgVidas[1][1].get_rect(center=(630, 17))
    rect_corazon_1 = img_corazon.get_rect(center=(RectTexto_1.midright[0] - 8, RectTexto_1.midright[1] - 3))
    rect_corazon_2 = img_corazon.get_rect(center=(RectTexto_2.midright[0] - 8, RectTexto_2.midright[1] - 3))
    
    def Refresh():
        PANTALLA.blit(Fondo, FondoRect)
        temp = Obstaculos_Fondo

        for obs in range(len(temp[0])):
            PANTALLA.blit(ImagenObstaculo, temp[0][obs])

        for obs in range(len(temp[1])):
            PANTALLA.blit(ImagenCajaQueSeRompe, temp[1][obs])

        # for point in Puntos:
        #    pygame.draw.circle(PANTALLA, (255, 0, 0), point, 3)
        
        PANTALLA.blits([(img_corazon, rect_corazon_1),
                        (img_corazon, rect_corazon_2),
                        (ImgVidas[1][P_1.vidas], RectTexto_1),
                        (ImgVidas[2][P_2.vidas], RectTexto_2)])


    def Colisiones(Jugador, obs) -> None:
        jugador_hitbox = Jugador.hitbox

        # Coordenadas del jugador
        j_left = jugador_hitbox.left
        j_right = jugador_hitbox.right
        j_top = jugador_hitbox.top
        j_bottom = jugador_hitbox.bottom

        # Coordenadas del obstáculo
        obs_left = obs.left
        obs_right = obs.right
        obs_top = obs.top
        obs_bottom = obs.bottom

        # Colisión por la derecha
        if (j_right > obs_left and j_left < obs_left and
            ((j_bottom >= obs_top and j_bottom <= obs_bottom) or
            (j_top <= obs_bottom and j_top >= obs_top)) and
                (j_right < obs_left + 5)):
            Jugador.hitbox.x -= Jugador.velocidad
            return 0

        # Colisión por la izquierda
        if (j_left < obs_right and j_right > obs_right and
            ((j_bottom >= obs_top and j_bottom <= obs_bottom) or
            (j_top <= obs_bottom and j_top >= obs_top)) and
                (j_left > obs_right - 5)):
            Jugador.hitbox.x += Jugador.velocidad
            return 0

        # Colisión por abajo
        if (j_bottom > obs_top and j_top < obs_top and
            ((j_right >= obs_left and j_right <= obs_right) or
            (j_left <= obs_right and j_left >= obs_left)) and
                (j_bottom < obs_top + 5)):
            Jugador.hitbox.y -= Jugador.velocidad
            return 0

        # Colisión por arriba
        if (j_top < obs_bottom and j_bottom > obs_bottom and
            ((j_right > obs_left and j_right < obs_right) or
            (j_left < obs_right and j_left > obs_left)) and
                (j_top > obs_bottom - 5)):
            Jugador.hitbox.y += Jugador.velocidad
            return 0

        return None
    
        
    P_1 = Player(114, 114, Velocidad_Player_1, PANTALLA,
                 1, Sprites_Player_1, (114, 114))
    P_2 = Player(594, 534, Velocidad_Player_2, PANTALLA,
                 2, Sprites_Player_2, (594, 534))

    create_bombas = ([Bomb(PANTALLA) for _ in range(2)] for _ in range(2))
    Bombas: list = list(create_bombas)
    
    posiciones_1, posiciones_2 = [[0, 0], [0, 0]], [[0, 0], [0, 0]]
    Tiempos_Bombas_1: list = [[0, 0], [0, 0]]
    Tiempos_Bombas_2: list = [[0, 0], [0, 0]]
    
    create_Powers = (PowerUp(PANTALLA, Puntos) for _ in range(3))
    POWER_UPS: list = list(create_Powers)
    
    TiempoPower_invencibilidad_1 = 0
    TiempoPower_invencibilidad_2 = 0
    Tiempo_Power_vel_1 = 0
    Tiempo_Power_vel_2 = 0

    pygame.init()

    # Genera un evento después de cierto tiempo, esta fórmula es para que sea lo mas fluido podible pero que no requiera demasiado proceso
    pygame.time.set_timer(True, 45)
    pygame.mouse.set_visible(False)

    Jugar: bool = True
    while Jugar:

        for event in pygame.event.get():
            Refresh()
            # Quitar juego :
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            # Detecta qué tecla se está presionando :
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    exit()

                # Teclas para activar las Bombas :
                if event.key == pygame.K_e:
                    Bombas_Puestas = [Bombas[0][0].BombaPuesta,
                                      Bombas[0][1].BombaPuesta]

                    if False in Bombas_Puestas:
                        x = Bombas_Puestas.index(False)
                        POS = P_1.Posicion_De_Bomba()
                        rect = pygame.rect.Rect(POS[0], POS[1], 30, 30)
                        Tiempos_Bombas_1[x][0] = pygame.time.get_ticks()

                        if (Tiempos_Bombas_1[x][0] - Tiempos_Bombas_1[x][1] > 8000) and rect.collidelist(Obstaculos_Fondo[0]) == -1 and rect.collidelist(Obstaculos_Fondo[1]) == -1:
                            Bombas[0][x].time_Bomb_1 = pygame.time.get_ticks()
                            Bombas[0][x].BombaPuesta = True
                            posiciones_1[x] = P_1.Posicion_De_Bomba()
                            Tiempos_Bombas_1[x][1] = pygame.time.get_ticks()

                if event.key == pygame.K_KP2:
                    Bombas_Puestas = [Bombas[1][0].BombaPuesta,
                                      Bombas[1][1].BombaPuesta]

                    if False in Bombas_Puestas:
                        x = Bombas_Puestas.index(False)
                        POS = P_2.Posicion_De_Bomba()
                        rect = pygame.rect.Rect(POS[0], POS[1], 30, 30)
                        Tiempos_Bombas_2[x][0] = pygame.time.get_ticks()

                        if (Tiempos_Bombas_2[x][0] - Tiempos_Bombas_2[x][1] > 8000) and rect.collidelist(Obstaculos_Fondo[0]) == -1 and rect.collidelist(Obstaculos_Fondo[1]) == -1:
                            Bombas[1][x].time_Bomb_1 = pygame.time.get_ticks()
                            Bombas[1][x].BombaPuesta = True
                            posiciones_2[x] = P_2.Posicion_De_Bomba()
                            Tiempos_Bombas_2[x][1] = pygame.time.get_ticks()


            # ---------------- Colisiones con Obstaculos : ----------------
            colision_1_1: int = P_1.hitbox.collidelist(Obstaculos_Fondo[0])
            colision_1_2: int = P_1.hitbox.collidelist(Obstaculos_Fondo[1])

            colision_2_1: int = P_2.hitbox.collidelist(Obstaculos_Fondo[0])
            colision_2_2: int = P_2.hitbox.collidelist(Obstaculos_Fondo[1])

            # Colisiones Jugador 1 :
            if colision_1_1 > -1:
                Colisiones(P_1, Obstaculos_Fondo[0][colision_1_1])
            if colision_1_2 > -1:
                Colisiones(P_1, Obstaculos_Fondo[1][colision_1_2])

            # Colisiones Jugador 2 :
            if colision_2_1 > -1:
                Colisiones(P_2, Obstaculos_Fondo[0][colision_2_1])
            if colision_2_2 > -1:
                Colisiones(P_2, Obstaculos_Fondo[1][colision_2_2])

            Bombas[0][0].Dibujar_Bomba(
                posiciones_1[0], Puntos, Obstaculos_Fondo, POWER_UPS)
            Bombas[0][1].Dibujar_Bomba(
                posiciones_1[1], Puntos, Obstaculos_Fondo, POWER_UPS)
            Bombas[1][0].Dibujar_Bomba(
                posiciones_2[0], Puntos, Obstaculos_Fondo, POWER_UPS)
            Bombas[1][1].Dibujar_Bomba(
                posiciones_2[1], Puntos, Obstaculos_Fondo, POWER_UPS)
            # ----------------------------------------------------------------

            # ---------------- Detectar si tocan una explosión : -----------
            P_1.Contacto_Bomba(
                [Bombas[0][0].RectHorizontal, Bombas[0][0].RectVertical,
                 Bombas[0][1].RectHorizontal, Bombas[0][1].RectVertical,
                 Bombas[1][0].RectHorizontal, Bombas[1][0].RectVertical,
                 Bombas[1][1].RectHorizontal, Bombas[1][1].RectVertical]
            )

            P_2.Contacto_Bomba(
                [Bombas[0][0].RectHorizontal, Bombas[0][0].RectVertical,
                 Bombas[0][1].RectHorizontal, Bombas[0][1].RectVertical,
                 Bombas[1][0].RectHorizontal, Bombas[1][0].RectVertical,
                 Bombas[1][1].RectHorizontal, Bombas[1][1].RectVertical]
            )
            # ---------------------------------------------------------------

            # -------------- Tiempo para que aparezca un Power Up :-------------

            for i in range(len(POWER_UPS)):
                POWER_UPS[i].DibujarPower(TiempoDePowerUps, [P_1, P_2])

            # -------------- Tiempo de la Power_invencibilidad : --------------
            if P_1.Power_invencibilidad:
                if TiempoPower_invencibilidad_1 - P_1.Power_inv_tiempo >= 8000:
                    P_1.Power_invencibilidad = False
                    P_1.Power_inv_tiempo = pygame.time.get_ticks()
                else:
                    P_1.Power_invencibilidad = True
                    TiempoPower_invencibilidad_1 = pygame.time.get_ticks()

            if P_2.Power_invencibilidad:
                if TiempoPower_invencibilidad_2 - P_2.Power_inv_tiempo >= 8000:
                    P_2.Power_invencibilidad = False
                    P_2.Power_inv_tiempo = pygame.time.get_ticks()
                else:
                    P_2.Power_invencibilidad = True
                    TiempoPower_invencibilidad_2 = pygame.time.get_ticks()
            # ----------------------------------------------------------------------

            # -------------- Tiempo del Power_Velocidad --------------
            if P_1.Power_Velocidad:
                if Tiempo_Power_vel_1 - P_1.Power_vel_tiempo >= 8000:
                    P_1.Power_Velocidad = False
                    P_1.Power_vel_tiempo = pygame.time.get_ticks()
                else:
                    P_1.Power_Velocidad = True
                    Tiempo_Power_vel_1 = pygame.time.get_ticks()

            if P_2.Power_Velocidad:
                if Tiempo_Power_vel_2 - P_2.Power_vel_tiempo >= 8000:
                    P_2.Power_Velocidad = False
                    Tiempo_Power_vel_2 = pygame.time.get_ticks()
                else:
                    P_2.Power_Velocidad = True
                    Tiempo_Power_vel_2 = pygame.time.get_ticks()

            P_1.Movement()
            P_2.Movement()

            TopesDePantalla(P_1)
            TopesDePantalla(P_2)

            P_1.Dibujar()
            P_2.Dibujar()
            

            P_1.ActualizarSprites()
            P_2.ActualizarSprites()

            if P_1.vidas == 0:
                Jugar = False

            elif P_2.vidas == 0:
                Jugar = False

            pygame.display.flip()
            clock.tick(FPS)
            
    if P_1.vidas == 0:
        Pantalla_Fin(2, main)

    if P_2.vidas == 0:
        Pantalla_Fin(1, main)

main()

