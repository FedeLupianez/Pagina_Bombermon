import pygame
from pygame.locals import *
import random
# PowerUps = ["Vida", "Velocidad", "Invencibilidad", "EmpujarBomba"]


class Player():
    def __init__(self, x, y, speed, display, player, sprites, Respawn):
        self.hitbox = pygame.rect.Rect(x, y, 35, 35)
        self.velocidad = speed / 4
        self.display = display
        self.Player = player
        self.Respawn = Respawn
        self.BombX = 0
        self.BombY = 0
        self.vidas = 3
        self.Power_invencibilidad = False
        self.Power_inv_tiempo = 0
        self.Power_Velocidad = False
        self.Power_vel_tiempo = 0
        self.imgs = sprites
        self.girar = False
        self.Accion = 0
        self.SpriteIndex = 0
        self.TiempoDeActualizacion = pygame.time.get_ticks()
        self.Burbuja = pygame.transform.scale(
            pygame.image.load("Imgs/Poderes/Invencibilidad.png"), [40, 40])

    def Dibujar(self):
        # Dibuja al personaje en la pantalla que se le haya pasado como argumento al objeto:
        if self.Power_invencibilidad:
            self.display.blit(self.Burbuja, self.hitbox)
        self.display.blit(pygame.transform.flip(
            self.imgs[self.Accion][self.SpriteIndex], self.girar, False), self.hitbox)

    def Movement(self):
        # Detecta qué tecla está siendo presionada :
        Key = pygame.key.get_pressed()

        if self.Power_Velocidad:
            self.velocidad = 6
        else:
            self.velocidad = 3
        # Si se presiona una tecla a,w,s,d y es el jugador 1, se mueve, o, si presiona cualquier flecha y es el jugador 2, tambien se mueve:
        if (Key[K_d] == True and self.Player == 1) or (Key[K_RIGHT] == True and self.Player == 2):
            self.hitbox.centerx += self.velocidad
            #self.hitbox = self.hitbox.move(self.velocidad, 0)
            self.Accion = 1
            self.girar = True
        else:
            if (Key[K_a] == True and self.Player == 1) or (Key[K_LEFT] == True and self.Player == 2):
                self.hitbox.centerx -= self.velocidad
                #self.hitbox = self.hitbox.move(-self.velocidad, 0)
                self.Accion = 1
                self.girar = False
            else:
                if (Key[K_w] == True and self.Player == 1) or (Key[K_UP] == True and self.Player == 2):
                    #self.hitbox = self.hitbox.move(0, -self.velocidad)
                    self.hitbox.centery -= self.velocidad
                    self.Accion = 0
                else:
                    if (Key[K_s] == True and self.Player == 1) or (Key[K_DOWN] == True and self.Player == 2):
                        #self.hitbox = self.hitbox.move(0, self.velocidad)
                        self.hitbox.centery += self.velocidad
                        self.Accion = 2
                    else:
                        if self.Accion == 1:
                            self.SpriteIndex = 0

    def Posicion_De_Bomba(self):
        # Retorna la posición en la que está al momento de llamar a la función :
        return (list(self.hitbox.center))

    def Contacto_Bomba(self, Explosiones: list):
        Explosiones = [rect for rect in Explosiones if rect != None]
        if self.hitbox.collidelist(Explosiones) > -1 and not self.Power_invencibilidad:
            self.hitbox.center = self.Respawn
            self.vidas -= 1
            self.Power_invencibilidad = False
            self.Power_Velocidad = False
        
    def ActualizarSprites(self):
        TiempoEntreSprites = 250
        if (pygame.time.get_ticks() - self.TiempoDeActualizacion) > TiempoEntreSprites:
            self.SpriteIndex += 1
            pygame.time.wait(10)
            self.TiempoDeActualizacion = pygame.time.get_ticks()
            if self.SpriteIndex >= len(self.imgs[self.Accion]):
                self.SpriteIndex = 0
                pygame.time.wait(10)


class Bomb():
    def __init__(self, display: pygame.display):
        self.display = display
        self.Tiempo_De_Bomba: int = 5000
        self.ExplotionTime: int = 3000
        self.BombaPuesta: bool = False
        self.ExplotionTrue: bool = False
        self.display = display
        self.RectVertical = pygame.rect.Rect(0, 0, 0, 0)
        self.RectHorizontal = pygame.rect.Rect(0, 0, 0, 0)
        self.RectCentro = pygame.rect.Rect(0, 0, 0, 0)
        self.Pos = [0, 0]

        self.time_Bomb_1 = pygame.time.get_ticks()
        self.Imgs = [[], []]

        # Imágenes de la Bomba :
        for i in range(3):
            self.Imgs[0].append(pygame.transform.scale(pygame.image.load(
                f"Imgs/BombaYExplosion/Pokeball_{i}.png"), [25, 25]))

        # Imágenes de la explosión :
        self.Imgs[1].append(pygame.transform.scale(pygame.transform.rotate(
            pygame.image.load("Imgs/BombaYExplosion/Explosion.png"), 90), [30, 170]))
        self.Imgs[1].append(pygame.transform.scale(pygame.image.load(
            "Imgs/BombaYExplosion/Explosion.png"), [170, 30]))
        self.Imgs[1].append(pygame.transform.scale(pygame.image.load(
            "Imgs/BombaYExplosion/CentroExplosion.png"), [30, 30]))

        self.SpriteIndex = 0

    def Dibujar_Bomba(self, posicion: list, Puntos, Obstaculos, Powers: list):
        # Ve si la bomba está puesta :
        if self.BombaPuesta == True:
            self.ExplotionTrue = False
            for i in range(len(Puntos)):
                if posicion[0] > Puntos[i][0] - 45 and posicion[0] < Puntos[i][0] + 45:
                    self.Pos[0] = Puntos[i][0]
                if posicion[1] > Puntos[i][1] - 45 and posicion[1] < Puntos[i][1] + 45:
                    self.Pos[1] = Puntos[i][1]
            # Cuenta los milisegundos que pasaron
            time_Bomb_2 = pygame.time.get_ticks()

            # Si los milisegundos que sacamos la linea anterior, menos los milisegundos que pasaron desde que se inició el programa, son menores al tiempo
            # en el que tiene que estallar la bomba, la dibuja
            if (time_Bomb_2 - self.time_Bomb_1) < self.Tiempo_De_Bomba:
                self.SpriteIndex = 0
                if (time_Bomb_2 - self.time_Bomb_1) >= 3000:
                    self.SpriteIndex = 1
                else:
                    if (time_Bomb_2 - self.time_Bomb_1) >= 4000:
                        self.SpriteIndex = 2
                    else:
                        self.SpriteIndex = 0

                Rect_Bomba = pygame.rect.Rect(self.Pos[0] - 10, self.Pos[1] - 10, 20, 20)
                #Rect_Bomba.center = self.Pos[0], self.Pos[1]
                self.display.blit(self.Imgs[0][self.SpriteIndex], Rect_Bomba)

                time_Bomb_2 = pygame.time.get_ticks()
                self.BombaPuesta = True
                self.ExplotionTrue = False
            else:
                # Si no, reseta el tiempo inicial, desactiva la función de bomba, y activa la función de la explosión :
                self.time_Bomb_1 = pygame.time.get_ticks()
                self.BombaPuesta = False
        else:
            self.ExplotionTrue = True

            if self.ExplotionTrue == True and self.Pos != [0, 0]:

                self.RectVertical = pygame.rect.Rect(self.Pos[0] - 15, self.Pos[1] - 85, 30, 170)
                self.RectHorizontal = pygame.rect.Rect(self.Pos[0] - 85, self.Pos[1] - 15, 170, 30)
                self.RectCentro = pygame.rect.Rect(self.Pos[0] - 15, self.Pos[1] - 15, 30, 30)

                for obs in Obstaculos[0]:
                    if self.RectHorizontal.colliderect(obs):
                        self.RectHorizontal = None
                        break
                    if self.RectVertical.colliderect(obs):
                        self.RectVertical = None
                        break

                for obs in Obstaculos[1]:
                    if (self.RectHorizontal != None and self.RectHorizontal.colliderect(obs)) or (self.RectVertical != None and self.RectVertical.colliderect(obs)):
                        Obstaculos[1] = [i for i in Obstaculos[1] if i != obs]
                        Powers.append(PowerUp(self.display, Puntos))

                # Mismo funcionamiento que del tiempo la bomba :
                time_Explotion_2 = pygame.time.get_ticks()

                if (time_Explotion_2 - self.time_Bomb_1) < self.ExplotionTime:
                    if self.RectVertical != None:
                        self.display.blit(self.Imgs[1][0], self.RectVertical)

                    if self.RectHorizontal != None:
                        self.display.blit(self.Imgs[1][1], self.RectHorizontal)

                    if self.RectHorizontal != None and self.RectVertical != None:
                        self.display.blit(self.Imgs[1][2], self.RectCentro)

                    self.ExplotionTrue = True
                    time_Explotion_2 = pygame.time.get_ticks()

                else:
                    self.ExplotionTrue = False
                    self.time_Explotion_1 = pygame.time.get_ticks()

                    self.RectVertical = None
                    self.RectHorizontal = None
                    self.RectCentro = None


# Power ups :
class PowerUp():
    def __init__(self, pantalla: pygame.display, Puntos: list):
        self.PowerUps = ['Vida', 'Invencibilidad', 'Velocidad']
        self.hitbox = pygame.rect.Rect(0, 0, 25, 25)
        self.pantalla = pantalla
        self.Puntos = Puntos
        self.Tipo = self.PowerUps[random.randint(0, len(self.PowerUps) - 1)]
        self.hitbox.center = self.Puntos[random.randint(0, len(Puntos) - 1)]

        self.tiempo_1 = pygame.time.get_ticks()

        match self.Tipo:
            case 'Vida':
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Vida.png"), [25, 25])

            case 'Velocidad':
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Velocidad.png"), [40, 40])

            case "Invencibilidad":
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Invencibilidad.png"), [25, 25])

            case "EmpujarBomba":
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/EmpujarBomba.png"), [25, 25])

    def DibujarPower(self, TiempoQueDura, ListaPlayers: list):
        self.tiempo_2 = pygame.time.get_ticks()

        ListaHitbox = [ListaPlayers[0].hitbox, ListaPlayers[1].hitbox]
        if ((self.tiempo_2 - self.tiempo_1) < TiempoQueDura):
            if self.hitbox.center != (0, 0):
                self.pantalla.blit(self.img, self.hitbox)
                x = self.hitbox.collidelist(ListaHitbox)
                match self.Tipo:
                    case 'Vida':
                        if x > -1 and ListaPlayers[x].vidas < 5:
                            ListaPlayers[x].vidas += 1
                            self.hitbox.center = (0, 0)

                    case 'Velocidad':
                        if x > -1:
                            ListaPlayers[x].Power_Velocidad = True
                            self.hitbox.center = (0, 0)
                            ListaPlayers[x].Power_vel_tiempo = pygame.time.get_ticks(
                            )

                    case 'Invencibilidad':
                        if x > -1:
                            ListaPlayers[x].Power_invencibilidad = True
                            self.hitbox.center = (0, 0)
                            ListaPlayers[x].Power_inv_tiempo = pygame.time.get_ticks(
                            )

                self.tiempo_2 = pygame.time.get_ticks()
        else:
            self.tiempo_1 = pygame.time.get_ticks()
            self.CambiarPos(self.Puntos)
            self.TipoAlAzar()

    def CambiarPos(self, Puntos):
        self.hitbox.center = Puntos[int(random.randint(0, len(Puntos) - 1))]

    def TipoAlAzar(self):
        self.Tipo = self.PowerUps[random.randint(0, len(self.PowerUps) - 1)]
        match self.Tipo:
            case 'Vida':
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Vida.png"), [25, 25])

            case 'Velocidad':
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Velocidad.png"), [40, 40])

            case "Invencibilidad":
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/Invencibilidad.png"), [25, 25])

            case "EmpujarBomba":
                self.img = pygame.transform.scale(
                    pygame.image.load("Imgs/Poderes/EmpujarBomba.png"), [25, 25])
