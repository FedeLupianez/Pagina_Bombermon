import pygame
from pygame.locals import *

pygame.init()

Pantalla = pygame.display.set_mode((740, 640))
pygame.display.set_caption("Skins")
pygame.display.set_icon(pygame.image.load(
    "Imgs/BombaYExplosion/Pokeball_0.png"))

RectEleccion = pygame.rect.Rect(490, 280, 30, 30)

FlechaAvanzar = pygame.rect.Rect(520, 380, 25, 25)
FlechaAtras = pygame.rect.Rect(460, 380, 25, 25)


# Cargar Imágenes:
Sprites = [[], [], [], [], [], [], []]

for i in range(2):
    Sprites[0].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Charizard/Frente_{i}.png"), [100, 100]))
    Sprites[1].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Gengard/Frente_{i}.png"), [100, 100]))
    Sprites[2].append(pygame.transform.scale(pygame.image.load(
        f"Imgs/Charmander/Frente_{i}.png"), [100, 100]))
    Sprites[3].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Clefairy/Frente_{i}.png"), [100, 100]))
    Sprites[4].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Cubone/Frente_{i}.png"), [100, 100]))
    Sprites[5].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Meowth/Frente_{i}.png"), [100, 100]))
    Sprites[6].append(pygame.transform.scale(
        pygame.image.load(f"Imgs/Pikachu/Frente_{i}.png"), [100, 100]))

letra = pygame.font.Font('Imgs/Minecraft.ttf', 20)
Pokedex = [pygame.transform.scale(pygame.image.load("Imgs/Menu_De_Eleccion/Pokedex_p1.png"), [380, 550]),
           pygame.transform.scale(pygame.image.load("Imgs/Menu_De_Eleccion/Pokedex_p2.png"), [380, 550])]

RectPoke = pygame.rect.Rect(0, 0, 320, 500)
RectPoke.center = (500, 330)

Fondo = pygame.transform.scale(pygame.image.load(
    "Imgs/Menu_De_Eleccion/Campo_de_batalla.png"), [740, 640])
RectFondo = Fondo.get_rect()


Flecha_1 = pygame.transform.scale(pygame.image.load(
    "Imgs/Menu_De_Eleccion/Flecha.png"), [50, 25])
Flecha_2 = pygame.transform.flip(pygame.transform.scale(
    pygame.image.load("Imgs/Menu_De_Eleccion/Flecha.png"), [50, 25]), True, False)

RectFlecha_1, RectFlecha_2 = Flecha_1.get_rect(), Flecha_2.get_rect()
RectFlecha_1.center, RectFlecha_2.center = (
    RectEleccion.centerx + 125, 320), (RectEleccion.centerx - 50, 320)

BTN_JUGAR_IMG = pygame.transform.scale(
    pygame.image.load('Imgs/Menu_De_Eleccion/Btn_Jugar.png'), [200, 50])
BTN_JUGAR_RECT = pygame.rect.Rect(50, 100, 200, 120)
# -----------------------------------------------------------------------------------------------------------------


def Refresh(Seleccion: int, Sprite_Index: int, n: int, err: str, tiempo_txt: int):

    Pantalla.blit(Fondo, RectFondo)
    Pantalla.blit(Pokedex[n], RectPoke)

    Pantalla.blit(BTN_JUGAR_IMG, BTN_JUGAR_RECT)
    Pantalla.blit(Flecha_1, RectFlecha_1)
    Pantalla.blit(Flecha_2, RectFlecha_2)
    Pantalla.blit(Sprites[Seleccion][Sprite_Index], RectEleccion)

    # Mostrar Errores en pantalla :
    if err:
        if pygame.time.get_ticks() - tiempo_txt < 5000: 
            texto = letra.render(err, True, (0, 0, 0))
            rect = texto.get_rect()
            rect.centerx = Pantalla.get_rect().centerx
            rect.y = 600
            Pantalla.blit(texto, rect)


NumerosDeSprites = {"Charizard": 4, "Gengard": 2, "Charmander": 3,
                    "Clefairy": 3, "Cubone": 3, "Meowth": 3,
                    "Pikachu": 3}

NumeroDePokemon = {0: "Charizard", 1: "Gengard", 2: "Charmander",
                   3: "Clefairy", 4: "Cubone", 5: "Meowth", 6: "Pikachu"}

pygame.time.set_timer(True, 300)


def Menu():
    tiempo_txt: int = 0
    n = 0
    Seleccion = 0
    Jugar = False
    skin_1 = ''
    skin_2 = ''
    Sprite_Index = 0
    err = ''
    while not Jugar:
        # Funcion para detectar los eventos :
        for event in pygame.event.get():
            # -----------------------------

            # Reiniciar o sumar indice de imágen :
            if Sprite_Index == 1:
                Sprite_Index = 0
            else:
                pygame.time.wait(10)
                Sprite_Index += 1

            if event.type == QUIT:
                pygame.quit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()

                if event.key == pygame.K_RIGHT:
                    Seleccion += 1

                    if Seleccion > 6:
                        Seleccion = 0

                if event.key == pygame.K_LEFT:
                    Seleccion -= 1
                    if Seleccion < 0:
                        Seleccion = 6

                if event.key == pygame.K_RETURN:
                    if skin_1 == "":
                        skin_1 = NumeroDePokemon[Seleccion]
                        err = 'Jugador 1 selecionado'
                        tiempo_txt = pygame.time.get_ticks()
                        n = 1
                    else:
                        if skin_2 == "":
                            skin_2 = NumeroDePokemon[Seleccion]

                            if skin_1 != "" and skin_2 != "":
                                err = 'Toca "Start" :D'
                                tiempo_txt = pygame.time.get_ticks()
                                break
                                               

            if (event.type == pygame.MOUSEBUTTONDOWN and BTN_JUGAR_RECT.collidepoint(pygame.mouse.get_pos())) or (event.type == pygame.KEYDOWN and event.key == pygame.K_0):
                if (skin_1 != '' and skin_2 != ''):
                    Jugar = True
                else: 
                    err = 'Seleccionen las skins'
                    tiempo_txt = pygame.time.get_ticks()
            
            Refresh(Seleccion, Sprite_Index, n, err, tiempo_txt)
            pygame.display.update()

    # Cargar las imagenes de todas las animaciones :
    SpritesPlayer_1 = [[], [], []]
    for i in range(NumerosDeSprites[skin_1]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_1}/Atras_{i}.png"), [40, 40])
        SpritesPlayer_1[0].append(img)

    for i in range(NumerosDeSprites[skin_1]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_1}/Costado_{i}.png"), [40, 40])
        SpritesPlayer_1[1].append(img)

    for i in range(NumerosDeSprites[skin_1]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_1}/Frente_{i}.png"), [40, 40])
        SpritesPlayer_1[2].append(img)

    SpritesPlayer_2 = [[], [], []]
    for i in range(NumerosDeSprites[skin_2]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_2}/Atras_{i}.png"), [40, 40])
        SpritesPlayer_2[0].append(img)

    for i in range(NumerosDeSprites[skin_2]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_2}/Costado_{i}.png"), [40, 40])
        SpritesPlayer_2[1].append(img)

    for i in range(NumerosDeSprites[skin_2]):
        img = pygame.transform.scale(pygame.image.load(
            f"Imgs/{skin_2}/Frente_{i}.png"), [40, 40])
        SpritesPlayer_2[2].append(img)

    return (SpritesPlayer_1, SpritesPlayer_2)


def Pantalla_Fin(jugador, funcion):
    Pantalla = pygame.display.set_mode([740, 640])
    pygame.mouse.set_visible(True)
    letra = pygame.font.Font("Imgs/Minecraft.ttf", 30)
    ImagenTexto = letra.render(
        f"!!!!! Jugador {jugador} Ganó !!!!!!!", True, (255, 255, 255), (0, 0, 0))
    RectImagen = ImagenTexto.get_rect(center=Pantalla.get_rect().center)

    ejecutar = True
    while ejecutar:
        Pantalla.blit(ImagenTexto, RectImagen)
        for event in pygame.event.get():

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()

                if event.key == pygame.K_RETURN:
                    ejecutar = False

            if event.type == QUIT:
                pygame.quit()

            pygame.display.update()
    Pantalla = pygame.display.set_mode((740, 640))
    funcion()